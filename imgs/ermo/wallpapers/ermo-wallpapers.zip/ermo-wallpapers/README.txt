Thanks for downloading ERMO wallpapers.
Hope you enjoy.

ERMO is an ethereal game about harmony and inner peace
http://nng.li/ermo

ERMO is available for iOS, Android, Windows and Steam.

Please spread the word to support my work on indie games.
Suggestions and comments are welcome.

by Nonostante
www.nonostante.io